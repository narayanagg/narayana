import React,{Component} from 'react';
import logo from './logo.svg';
import {BrowserRouter,Route} from "react-router-dom";
import './App.css';

//components
import Home from "./Comp/Home";
import Artists from "./Comp/Artists";

export default class App extends React.Component{
  render(){
    return(
      <div>
        <BrowserRouter> 
        <Route path="/"component={Home} exact></Route>
        <Route path="/Artists/:Aid"component={Artists} ></Route>
        
        </BrowserRouter>
      </div>
    )
  }
}


