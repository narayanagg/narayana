import React,{Component} from "react";
export default class Profile extends React.Component{
    render(){
        return(
            <div>Profile Comp</div>
        )
    }
}