import React,{Component} from "react";
export default class Home extends React.Component{
    render(){
        return(
            <div>Home Comp</div>
        )
    }
}