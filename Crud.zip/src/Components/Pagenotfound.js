import React,{Component} from "react";
export default class Page extends React.Component{
    render(){
        return(
            <div>Page Comp not found</div>
        )
    }
}