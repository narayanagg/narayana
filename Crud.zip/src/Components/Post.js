import React,{Component} from "react";
export default class Post extends React.Component{
    render(){
        return(
            <div>Post Comp</div>
        )
    }
}