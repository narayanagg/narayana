import React,{Component} from "react";
import Banner from "./Banner";
export default class Home extends React.Component{
    render(){
        return(
            <div>
                <Banner/>
                music db home
            </div>
        )
    }
}