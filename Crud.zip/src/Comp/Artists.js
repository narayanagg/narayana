import React,{Component} from "react";
export default class Artists extends React.Component{
    render(){
        return(
            <div>
                Artists page
            </div>
        )
    }
}